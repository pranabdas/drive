#!/bin/sh

# a simple wrapper

eval "$@"
