#!/bin/sh

# a simple wrapper

pwd