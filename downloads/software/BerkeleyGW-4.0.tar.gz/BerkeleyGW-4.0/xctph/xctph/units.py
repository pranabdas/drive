#!/usr/bin/env python

amu2me = 1822.89
har2ryd = 2
ryd2ev = 13.605698066
ryd2mev = ryd2ev * 1000
kelvin2ev = 8.6173427909e-5
bohr2ang = 0.529177249
hbar = 6.58211956e-16
tol = 1e-6
