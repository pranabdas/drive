#!/bin/bash


#SBATCH -N 1
#SBATCH -C cpu
#SBATCH -q debug
#SBATCH -t 00:30:00
#SBATCH -A m2651

#OpenMP settings:
export OMP_NUM_THREADS=1
export OMP_PLACES=threads
export OMP_PROC_BIND=spread

module load espresso
module load berkeleygw/3.0.1-cpu

MPIRUN='srun -n 16 -c 4 --cpu_bind=cores'
EPSILON='epsilon.cplx.x'

ln -nfs ../02-wfn/wfn.cplx WFN
ln -nfs ../03-wfnq/wfn.cplx WFNq

$MPIRUN $EPSILON &> epsilon.out

