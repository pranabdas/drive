#!/bin/bash


#SBATCH -N 1
#SBATCH -C cpu
#SBATCH -q debug
#SBATCH -t 00:30:00
#SBATCH -A m2651

#OpenMP settings:
export OMP_NUM_THREADS=1
export OMP_PLACES=threads
export OMP_PROC_BIND=spread

module load espresso
module load berkeleygw/3.0.1-cpu

MPIRUN='srun -n 16 -c 4 --cpu_bind=cores'
SIGMA='sigma.cplx.x'

ln -nfs ../02-wfn/wfn.cplx WFN_inner
ln -nfs ../02-wfn/rho.real RHO
ln -nfs ../02-wfn/vxc.dat vxc.dat
ln -nfs ../11-epsilon/eps0mat.h5 eps0mat.h5
ln -nfs ../11-epsilon/epsmat.h5 epsmat.h5

$MPIRUN $SIGMA &> sigma.out

