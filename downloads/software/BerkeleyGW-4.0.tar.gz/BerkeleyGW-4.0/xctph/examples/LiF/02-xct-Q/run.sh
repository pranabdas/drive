#!/bin/bash


#SBATCH -N 1
#SBATCH -C cpu
#SBATCH -q debug
#SBATCH -t 00:30:00
#SBATCH -A m2651

#OpenMP settings:
export OMP_NUM_THREADS=1
export OMP_PLACES=threads
export OMP_PROC_BIND=spread

module load espresso
module load berkeleygw/3.0.1-cpu


cd Q0000/02-kernel
bash run.sh
cd ../..
cd Q0000/03-singlet
bash run.sh
cd ../..
cd Q0001/02-kernel
bash run.sh
cd ../..
cd Q0001/03-singlet
bash run.sh
cd ../..
cd Q0002/02-kernel
bash run.sh
cd ../..
cd Q0002/03-singlet
bash run.sh
cd ../..
cd Q0003/02-kernel
bash run.sh
cd ../..
cd Q0003/03-singlet
bash run.sh
cd ../..
cd Q0004/02-kernel
bash run.sh
cd ../..
cd Q0004/03-singlet
bash run.sh
cd ../..
cd Q0005/02-kernel
bash run.sh
cd ../..
cd Q0005/03-singlet
bash run.sh
cd ../..
cd Q0006/02-kernel
bash run.sh
cd ../..
cd Q0006/03-singlet
bash run.sh
cd ../..
cd Q0007/02-kernel
bash run.sh
cd ../..
cd Q0007/03-singlet
bash run.sh
cd ../..

