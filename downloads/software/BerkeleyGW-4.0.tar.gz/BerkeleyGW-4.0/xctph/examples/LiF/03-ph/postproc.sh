#!/bin/bash 

PREFIX='LiF'

mkdir save

# copy the 
cp -r ./_ph0/$PREFIX.phsave/ ./save

# for some reason the dvsf file for q 1 is in a different place
cp ./_ph0/$PREFIX.dvscf1 ./save/$PREFIX.dvscf_q1

for i in `seq 3`; do
  cp ./matdyn$i ./save/$PREFIX.dyn_q$i
  cp ./_ph0/$PREFIX.q_$i/$PREFIX.dvscf1 ./save/$PREFIX.dvscf_q$i
  #cp ./matdyn$i .
  echo $i
done
