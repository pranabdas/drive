#!/bin/bash


#SBATCH -N 1
#SBATCH -C cpu
#SBATCH -q debug
#SBATCH -t 00:30:00
#SBATCH -A m2651

#OpenMP settings:
export OMP_NUM_THREADS=1
export OMP_PLACES=threads
export OMP_PROC_BIND=spread

module load espresso
module load berkeleygw/3.0.1-cpu

MPIRUN='srun -n 16 -c 4 --cpu_bind=cores'
PH='ph.x'
PWFLAGS='-nk 2'


## pre-processing
PREFIX='LiF'

mkdir $PREFIX.save
cd $PREFIX.save
ln -nsf ../../01-xct/01-density/LiF.save/* .
cd ..

## run
$MPIRUN $PH $PWFLAGS -in ph.in &> ph.out


## post-processing
mkdir save

# copy the 
cp -r ./_ph0/$PREFIX.phsave/ ./save

# for some reason the dvsf file for q 1 is in a different place
cp ./_ph0/$PREFIX.dvscf1 ./save/$PREFIX.dvscf_q1

for i in `seq 3`; do
  cp ./matdyn$i ./save/$PREFIX.dyn_q$i
  cp ./_ph0/$PREFIX.q_$i/$PREFIX.dvscf1 ./save/$PREFIX.dvscf_q$i
  echo $i
done


