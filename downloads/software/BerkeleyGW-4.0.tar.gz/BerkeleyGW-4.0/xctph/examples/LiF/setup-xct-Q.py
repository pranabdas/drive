#!/usr/bin/env python

import numpy as np

from os.path import join as pjoin

from BGWpy import Structure, Workflow, QeScfTask, QeWfnTask, Qe2BgwTask, KernelTask, AbsorptionTask

workflow = Workflow(dirname='02-xct-Q')

# Common arguments for tasks.
kwargs = dict(

    structure = Structure.from_file('./structures/POSCAR'),
    prefix = 'LiF',
    pseudo_dir = './pseudos',
    pseudos = ['Li.upf', 'F.upf'],

    # Path to scf files
    wfn_co_fname='./01-xct/05-wfn_fi/wfn.cplx',
    wfn_fi_fname='./01-xct/05-wfn_fi/wfn.cplx',
    wfnq_co_fname='./01-xct/05-wfn_fi/wfn.cplx',
    wfnq_fi_fname='./01-xct/05-wfn_fi/wfn.cplx',

    # Path to dielectric files
    eps0mat_fname='./01-xct/11-epsilon/eps0mat.h5',
    epsmat_fname='./01-xct/11-epsilon/epsmat.h5',

    # Path to QP corrections
    eqp_fname='./01-xct/12-sigma/eqp1.dat',
    eqp_q_fname='./01-xct/12-sigma/eqp1.dat',

    # Universal kernel and absorption variables
    nbnd_val=3,
    nbnd_cond=1,
    nbnd_val_co=3,          # Number of valence bands on the coarse grid
    nbnd_cond_co=1,         # Number of conduction bands on the coarse grid
    nbnd_val_fi=3,          # Number of valence bands on the fine grid
    nbnd_cond_fi=1,         # Number of conduction bands on the fine grid

    # Parameters for the MPI runner
    nproc = '',
    nproc_per_node = '',
    mpirun = 'srun -n 64 -N 1 -c 4 --cpu_bind=cores',
    nproc_flag = '',
    nproc_per_node_flag = '',
    PWFLAGS = '-nk 4'
    )

nkx = 2
nky = 2
nkz = 2
delta_kx = 1.0 / nkx
delta_ky = 1.0 / nky
delta_kz = 1.0 / nkz

qshifts = list()
for ikx in range(nkx):
    for iky in range(nky):
        for ikz in range(nkz):
            qshifts.append([ikx * delta_kx, iky * delta_ky, ikz * delta_kz])

for iq, qq in enumerate(qshifts):

    # Set up q = 0 calculation
    if np.allclose(qq,[0.,0.,0.]):

        # Kernel task
        kerneltask = KernelTask(
            dirname = pjoin(workflow.dirname,'Q{:04d}/02-kernel'.format(iq)),
            extra_lines = [
                'no_symmetries_coarse_grid',
                'screening_semiconductor',
                'energy_loss',
            ],
            **kwargs)  

        # Absorption task
        singlettask = AbsorptionTask(
            dirname=pjoin(workflow.dirname,'Q{:04d}/03-singlet'.format(iq)),
            bsemat_fname=kerneltask.bsemat_fname,
            extra_lines = [
                'no_symmetries_coarse_grid',
                'no_symmetries_fine_grid',
                'no_symmetries_shifted_grid',
                'screening_semiconductor',
                'use_momentum',
                'gaussian_broadening',
                'write_eigenvectors -1',
                'degeneracy_check_override',
                'eqp_co_corrections',
                ],
            **kwargs)
        singlettask.runscript.append('$MPIRUN $ABSORPTION &> absorption.out')


        # Absorption task
        triplettask = AbsorptionTask(
            dirname=pjoin(workflow.dirname,'Q{:04d}/04-triplet'.format(iq)),
            bsemat_fname=kerneltask.bsemat_fname,
            extra_lines = [
                'no_symmetries_coarse_grid',
                'no_symmetries_fine_grid',
                'no_symmetries_shifted_grid',
                'screening_semiconductor',
                'use_momentum',
                'gaussian_broadening',
                'write_eigenvectors -1',
                'eqp_co_corrections',
                'spin_triplet',
                'degeneracy_check_override',
                ],
            **kwargs)
        triplettask.runscript['ABSORPTION'] = '/global/homes/j/jhaber/software/BerkeleyGW/bin/absorption.cplx.x'

    else:

        # Kernel task
        kerneltask = KernelTask(
            dirname = pjoin(workflow.dirname,'Q{:04d}/02-kernel'.format(iq)),
            extra_lines = [
                'no_symmetries_coarse_grid',
                'screening_semiconductor',
                'energy_loss',
                'exciton_Q_shift 0 {q[0]} {q[1]} {q[2]}'.format(q=qq),
            ],
            **kwargs)

        # Absorption task
        singlettask = AbsorptionTask(
            dirname=pjoin(workflow.dirname,'Q{:04d}/03-singlet'.format(iq)),
            bsemat_fname=kerneltask.bsemat_fname,
            extra_lines = [
                'no_symmetries_coarse_grid',
                'no_symmetries_fine_grid',
                'no_symmetries_shifted_grid',
                'screening_semiconductor',
                'use_velocity',
                'gaussian_broadening',
                'exciton_Q_shift 0 {q[0]} {q[1]} {q[2]}'.format(q=qq),
                'write_eigenvectors -1',
                'degeneracy_check_override',
                'eqp_co_corrections',
                'eqp_co_q_corrections',
                ],
            **kwargs)

        triplettask = AbsorptionTask(
            dirname=pjoin(workflow.dirname,'Q{:04d}/04-triplet'.format(iq)),
            bsemat_fname=kerneltask.bsemat_fname,
            extra_lines = [
                'no_symmetries_coarse_grid',
                'no_symmetries_fine_grid',
                'no_symmetries_shifted_grid',
                'screening_semiconductor',
                'use_velocity',
                'gaussian_broadening',
                'exciton_Q_shift 0 {q[0]} {q[1]} {q[2]}'.format(q=qq),
                'eqp_co_corrections',
                'eqp_co_q_corrections',
                'spin_triplet',
                'write_eigenvectors -1',
                'degeneracy_check_override',
                ],
            **kwargs)

    # Add all task without merging (executed from a sub-directory)
    workflow.add_tasks([kerneltask, singlettask], merge=False) 
    #workflow.add_tasks([kerneltask, singlettask, triplettask], merge=False) 

# Execution
workflow.write()
workflow.report()
