After installation users should have access to the following 5 command line utilities

1. write_xct_h5.py
2. write_eph_h5.py
3. compute_xctph_h5.py
4. print_eph.py
5. print_xctph.py

To check for proper instialltion type:
    `which write_xct_h5.py'

Each command line utility takes a number of agruments, for details on these arguments type:
    `write_xct_h5.py -h'


To extract exciton-phonon matrix elements for this run the following utilities in the terminal in this directory:

1. Extract exciton expansion coefficients:
    `write_xct_h5.py ../02-xct-Q/Q00\*/03-singlet/eigenvectors.h5'

2. Extract the electron-phonon matrix elements:
    `write_eph_h5.py ../04-eph/ LiF 8 1 3'

3. Compute exciton-phonon matrix elements:
    `compute_xctph.py eph.h5 xct.h5 2'

4. Print electron-phonon matrix elments:
    `print_eph.py eph.h5'

5. Print exciton-phonon matrix elments:
    `print_xctph.py xctph.h5'


Notes: 

1. For step 2 you will get a message about negative frequencies, 
please ignore this is an artifact of the calcualtion being very underconverged

2. All outputs should be compared with the those in the ref directory.

3. In xctph.h5 xctph matrix elments are ordered as follows xctph[iS',iS, iQ, inu, iq] 

