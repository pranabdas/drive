"""
Perform a complete BSE calculation including
the DFT wavefunctions, the inverse dielectric matrix, the self-energy,
the kernel, and the absorption spectrum.
"""
from BGWpy import Structure, BSEFlow


flow = BSEFlow(
    dirname= '01-xct',
    dft_flavor='espresso',

    structure = Structure.from_file('./structures/POSCAR'),
    prefix = 'LiF',
    pseudo_dir = './pseudos',
    pseudos = ['Li.upf', 'F.upf'],

    ecutwfc = 20.0,
    nbnd = 31,
    nbnd_fine = 12,

    ngkpt = [2,2,2],
    kshift = [0.0, 0.0, 0.0],
    qshift = [.0,.0,.001],
    #clean_after= False,

    # Fine grids
    ngkpt_fine = [2,2,2],
    kshift_fine = [0.0, 0.0, 0.0],

    ibnd_min = 2,
    ibnd_max = 12,
    ecuteps = 3.0,
    epsilon_extra_lines = ['degeneracy_check_override'],
    sigma_extra_lines = ['screening_semiconductor', 'degeneracy_check_override'],

    # Kernel variables
    nbnd_val = 3,
    nbnd_cond = 1,

    kernel_extra_lines = [
        'no_symmetries_coarse_grid',
        'screening_semiconductor',
        #'energy_loss'
        ],

    # Absorption variables
    nbnd_val_co=3,
    nbnd_cond_co=1,
    nbnd_val_fi=3,
    nbnd_cond_fi=1,
    
    absorption_extra_lines = [
        'no_symmetries_coarse_grid',
        'no_symmetries_fine_grid',
        'no_symmetries_shifted_grid',
        'screening_semiconductor',
        'use_momentum',
        'lorentzian_broadening',
        'write_eigenvectors -1',
        'degeneracy_check_override',
        'eqp_co_corrections'
        ],
    
    absorption_extra_variables = {
        'energy_resolution' : 0.02,
        },


    # Parameters for the MPI runner
    nproc = None,
    nproc_per_node = None,
    mpirun = 'srun -n 16 -c 4 --cpu_bind=cores',
    nproc_flag = None,
    nproc_per_node_flag = None,

    PWFLAGS = '-nk 2',
    )

# Execution
flow.write()
#flow.run()
flow.report()
