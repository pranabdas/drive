#!/bin/bash
tar --strip=2 -xzf Al-NW.tgz Al-NW/1-scf-wfn/{VSC,VKB,WFN_in}
tar -czf data.tgz VKB VSC WFN_in
rm VKB VSC WFN_in
