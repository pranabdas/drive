#!/bin/bash -l

for d in */; do
	cd $d
	fname_in=*.mako
	fname_out=$(basename $fname_in .mako)
	echo $fname_in $fname_out
	../gen_test.py $fname_in $fname_out
	cd ../
done
