import h5py
import numpy as np
import pickle
import os
from numba import jit
import time


@jit(nopython=True, cache=True, parallel=True)  # run function with numba including paralalization to make things quick
def calc_loop(ngk, wfn_cplx, nv, nc, S_mat, S, k_ind):
      starting_point = np.sum(ngk[:k_ind])  # find initial index of G vectors for this k point
      end_point = starting_point + ngk[k_ind]  #find last index of G vectors for this k point
      Id = np.identity(ngk[k_ind])  # identity matrix
      spin_mat = np.kron(S, Id)  # spin operator matrix
      for m in range(nv + nc):  # loop over all bands you wish to calculate the spin for, which will be used as the bra
            curr_wfn1 = wfn_cplx[m, :, starting_point:end_point]  # extract the wavefunction at each band
            bra = curr_wfn1.flatten().T.conj()  # store the bra
            for n in range(nv + nc):  # loop over ket states
                  curr_wfn2 = wfn_cplx[n, :, starting_point:end_point]  # extract the wavefuncion of the ket
                  ket = curr_wfn2.flatten()  # store the ket
                  spin_mat_elem = np.dot(bra, np.dot(spin_mat, ket))  # do the bracket by multiplying the bra with the spin operator matrix and then the ket
                  S_mat[m, n] = spin_mat_elem  # save data


def main(nv, nc, wfn_path, spin_direction):
      estimate_time_after_x_loops = 50
      wfn_file = h5py.File(os.path.join(wfn_path, 'WFN.h5'), 'r')  # open WFN file in BGW h5 format
      wfn = wfn_file['wfns/coeffs']  # read the wavefunction data
      vb = np.max(wfn_file['/mf_header/kpoints/ifmax'])  # find the valence band number
      minb = vb - nv  # find the lowest band index you wish to calculate
      maxb = vb + nc  # find the highest band inddex you wish to calculate 
      wfn_cplx = np.array(wfn[minb:maxb, :, :, 0] + wfn[minb:maxb, :, :, 1] * 1j)  # store the complex wavefunctions only for these bands
      del wfn  # get rid of the complete wavefunction data to reduce memory usage

      # Pauli matrix for the specific direction you wish to compute, according to input parameter
      if spin_direction == 3:
            S = np.array([[1, 0], [0, -1]], dtype='complex128')
            output_files_name = 'Sz'
      elif spin_direction == 1:
            S = np.array([[0, 1], [1, 0]], dtype='complex128')
            output_files_name = 'Sx'
      elif spin_direction == 2:
            S = np.array([[0, -1j], [1j, 0]], dtype='complex128')
            output_files_name = 'Sy'

      nk = wfn_file['mf_header/kpoints/nrk'][()]  # number of k points
      ngk = np.array(wfn_file['mf_header/kpoints/ngk'])  # numer of G vectors per K point
      wfn_file.close() # close WFN.h5 file
      all_S = np.zeros([nk, nv + nc, nv + nc], dtype=np.complex128)  # empty output matrix for all k-points
      for k in range(nk):  # loop over k points
            if k == 0:
                  print(str(k + 1) + '/' + str(nk))
            elif k == 1:
                  start_time = time.time()
                  print(str(k + 1) + '/' + str(nk))
            elif k < estimate_time_after_x_loops + 1:
                  print(str(k + 1) + '/' + str(nk))
            elif k == estimate_time_after_x_loops + 1:
                  end_time = time.time()
                  time_per_k = (end_time - start_time) / estimate_time_after_x_loops
                  print(str(k + 1) + '/' + str(nk), 'Estimated time to finish:', int((nk - k) * time_per_k), 'seconds.',
                        'Estimated finish time:', time.ctime(time.time() + (nk - k) * time_per_k))
            else:
                  print(str(k + 1) + '/' + str(nk), 'Estimated time to finish:', int((nk - k) * time_per_k), 'seconds.',
                        'Estimated finish time:', time.ctime(time.time() + (nk - k) * time_per_k))
            S_mat = np.zeros([nv + nc, nv + nc], dtype=np.complex128)  # empty output matrix for one k-point
            calc_loop(ngk, wfn_cplx, nv, nc, S_mat, S, k)  # call calculating function for (nv+nc)**2 elements
            all_S[k, :, :] = S_mat  # store the calculated k-point in the general array
      pick_file = open(os.path.join(wfn_path, output_files_name), 'wb')  # open results pickle file
      pickle.dump(all_S, pick_file)  # save the pickle
      pick_file.close()  # close the pickle file
      return


if __name__ == '__main__':
      import argparse
      parser = argparse.ArgumentParser()
      parser.add_argument('nv', type=int)  # number of valence bands you wish to calculate
      parser.add_argument('nc', type=int)  # number of conduction bands you wish to calculate
      parser.add_argument('wfn_path', type=str)  # path to where WFN.h5 is stored
      parser.add_argument('spin_direction', type=int)  # spin direction you wish to calculate. x=1, y=2, z=3.
      args = parser.parse_args()
      main(**vars(args))
