
### Overview - Circularly Polarized Light Absorption
This patch facilitates the calculation of absorption for circularly polarized light in two-dimensional systems. The process involves two Python scripts: one to determine the linear combination of reciprocal lattice vectors that are perpendicular to each other (essential for non-orthogonal lattice vectors, as in transition metal dichalcogenides).

After identifying the vector coefficients yielding perpendicular directions, two absorption calculations are performed, focusing solely on the non-interacting electron-hole components, which are computationally relatively easy.

Subsequently, the second Python script computes the circularly polarized dipole matrix elements. Finally, the absorption calculation can be rerun using these dipole matrix elements.

Please follow the steps outlined in the notebook in the BSE/MagneticSpin directory. Note that the code is optimized for using the momentum operator in absorption, specifically tailored for 2D systems with the out-of-plane direction as the z-direction.



### Overview - Off-diagonal Exciton Spin Matrix Elements

This is a patch designed to calculate the spin matrix elements of wavefunction along the x, y and z directions.
The first part calculated these in the single-particle level, by multiplying the electronic wavefunctions read from BerkeleyGW hdf5 format, with the Pauli matrices. 


The second part then reads the calculated electronic single particle spin elements and multiplies them with the excitonic wavefunctions calculated in BerkeleyGW with the absorption code and generate the spin matrix elements for excitons.


In both the electronic and exciton parts, the calculation includes the determination of off-diagonal elements. These off-diagonal elements can be particularly useful in scenarios involving degenerate states. Both calculations are performed using Python scripts.

Please adhere to the steps detailed in the notebook in the BSE/MagneticSpin directory. Currently, the scripts focus solely on calculating the spin magnetic moment elements, with plans to incorporate the orbital magnetic moment part in subsequent updates.



For any questions or further assistance, please do not hesitate to contact the developer, Tomer Amit, via email at amit.tomer@weizmann.ac.il.
