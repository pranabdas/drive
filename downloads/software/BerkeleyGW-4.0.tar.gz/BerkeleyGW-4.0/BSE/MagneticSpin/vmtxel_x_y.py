import h5py
import os
import numpy as np
import sys


dir = sys.argv[1]  # directory of initial absorption run
evecs_file_name = os.path.join(dir, 'eigenvectors.h5')  # eigenvectors.h5 file name
evecs_file = h5py.File(evecs_file_name, 'r')  # read eigenvectors.h5 file
bvecs = evecs_file['mf_header/crystal/bvec'][()]  # read reciprocal latticle vectors
evecs_file.close()  # close eigenvectors.h5 file
print('b vectors are:\n', bvecs)  # print reciprocal lattice vectors
b1 = bvecs[0, :]
b2 = bvecs[1, :]
b3 = bvecs[2, :]
x1 = b1[0]
x2 = b2[0]
y1 = b1[1]
y2 = b2[1]
assert(not b1[2])  # make sure that the system is 2D
assert(not b2[2])
assert(not b3[0])
assert(not b3[1])
if np.isclose(y1, 0.0):  #check if one of the previously calculated vmtxel is along x
    m = 1.0
    n = 0.0
    print('x direction already calculated as b1 in the initial absorption run')
elif np.isclose(y2, 0.0): #check if one of the previously calculated vmtxel is along x
    m = 0.0
    n = 1.0
    print('x direction already calculated as b2 in the initial absorption run')
else:  # calculate what should be the polarization vector so you'll get vmtxel along x
    n = (x2-y2*x1/y1)**(-1)
    m = -n*y2/y1
    print('for x direction, use:\npolarization', m.round(9), n.round(9), 0.0)

if np.isclose(x1, 0.0): #check if one of the previously calculated vmtxel is along y
    h = 0.0
    k = 1.0
    print('y direction already calculated as b1 in the initial absorption run')
elif np.isclose(x2, 0.0): #check if one of the previously calculated vmtxel is along y
    print('y direction already calculated as b2 in the initial absorption run')
else:  # calculate what should be the polarization vector so you'll get vmtxel along y
    h = (y2-x2*y1/x1)**(-1)
    k = -x2*h/x1
    print('for y direction, use:\npolarization', k.round(9), h.round(9), 0.0)

print('you should also add "noeh_only" to absorption.inp since you do not need the complete absorption calculation')
