import math


# run this after calculating the vmtxels in x and y, and convert them from binary to ascii using bsebinasc.cplx.x
x_file = 'vmtxel_x_ascii'  # x direction input file name, file in ascii format
y_file = 'vmtxel_y_ascii'  # y direction input file name, file in ascii format
output_file_name_header = 'vmtxel'  # output file name header
sigma_plus_real_part = []  # lists to store the newly calculated elements in
sigma_minus_real_part = []
sigma_plus_imag_part = []
sigma_minus_imag_part = []

fac = 1.0 / math.sqrt(2.0)  # renormalization factor to keep the absolute absorption the same

with open(x_file, 'r') as fh:  # read the header of the file which is stored in the first line
    first_line = fh.readline()
    head = first_line


with open(x_file, 'r') as fh:  # read the text and extract the numbers from it, for x direction
    full_text = fh.read().rstrip('\n')
    input_text = full_text.split(')')
    input_text[0] = input_text[0].lstrip(head)
    for i in range(len(input_text) - 1):
        number = input_text[i].split(',')
        real_part = float(number[0].lstrip().lstrip('(')) * fac  # real part of a matrix element
        imag_part = float(number[1]) * fac  # imaginary part
        sigma_plus_real_part.append(real_part)  
        sigma_minus_real_part.append(real_part)
        sigma_plus_imag_part.append(imag_part)
        sigma_minus_imag_part.append(imag_part)


with open(y_file, 'r') as fh:  # read the y direction input file
    full_text = fh.read().rstrip('\n')
    input_text = full_text.split(')')
    input_text[0] = input_text[0].lstrip(head)
    for i in range(len(input_text) - 1):
        number = input_text[i].split(',')
        real_part = float(number[0].lstrip().lstrip('(')) * fac
        imag_part = float(number[1]) * fac
        sigma_plus_real_part[i] = sigma_plus_real_part[i] - imag_part  # add/subtract y from x
        sigma_minus_real_part[i] = sigma_minus_real_part[i] + imag_part
        sigma_plus_imag_part[i] = sigma_plus_imag_part[i] + real_part
        sigma_minus_imag_part[i] = sigma_minus_imag_part[i] - real_part


outfile = open(output_file_name_header + '_sigma_plus_ascii', "w")  # write sigma plus output file
outfile.write(head)  # write header
for n in range(len(sigma_plus_real_part)):  # write numbers and signs to keep the same format
    outfile.write('(')
    outfile.write(str(sigma_plus_real_part[n]))
    outfile.write(',')
    outfile.write(str(sigma_plus_imag_part[n]))
    outfile.write(')')
    outfile.write('       ')
outfile.close()

outfile = open(output_file_name_header + '_sigma_minus_ascii', "w")  # write sigma minus output file
outfile.write(head)
for n in range(len(sigma_plus_real_part)):
    outfile.write('(')
    outfile.write(str(sigma_minus_real_part[n]))
    outfile.write(',')
    outfile.write(str(sigma_minus_imag_part[n]))
    outfile.write(')')
    outfile.write('       ')
outfile.close()

# you now have the vmtxel files in ascii format in the sigma directions
# you should convert them from ascii to bin using bseascbin.cplx.x
# don't forget to also link b3, the out-of-plane direction (you can also link another vmtxel in the same format, but you must have this link otherwise BGW will fail)
