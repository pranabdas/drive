import pickle
import os
import numpy as np
from numba import jit
import h5py


def map_grid2grid(kpts, kpts_2, shift=np.array([0, 0, 0], dtype=float)):
    '''
    Mapping the first grid (with shift of Q) to the second one.
    Parameters:
        kpts = first grid k-points in crystal coordinates (float array with a shape of [nk, 3])
        kpts_2 = second grid k-points in crystal coordinates (float array with a shape of [nk, 3])
        shift (optional) = The shift of the first grid (float array with length of 3)
    Return:
        map_kpts2kpts_2 = The indices of the first grid k-points in the second grid (list of integers).
    '''
    kpts_2 = kpts_2 - np.repeat(shift[np.newaxis, :], len(kpts_2), axis=0)
    map_kpts2kpts_2 = []
    for k in range(len(kpts)):
        k_match = np.argwhere(np.all(np.isclose(kpts[k, :], kpts_2), axis=1))
        if len(k_match) == 0:
            for neg in np.argwhere(kpts < 0):
                kpts[neg[0], neg[1]] = kpts[neg[0], neg[1]] + 1
            for ones in np.argwhere(np.isclose(kpts, 1)):
                kpts[ones[0], ones[1]] = kpts[ones[0], ones[1]] - 1
            for neg in np.argwhere(kpts_2 < 0):
                kpts_2[neg[0], neg[1]] = kpts_2[neg[0], neg[1]] + 1
            for ones in np.argwhere(np.isclose(kpts_2, 1)):
                kpts_2[ones[0], ones[1]] = kpts_2[ones[0], ones[1]] - 1
            k_match = np.argwhere(np.all(np.isclose(kpts[k, :], kpts_2), axis=1))
            if len(k_match) == 0:
                print('problems in mapping... k=', kpts[k, :])
        map_kpts2kpts_2.append(k_match[0][0])
    return map_kpts2kpts_2


@jit(nopython=True, cache=True, parallel=True)
def spin_loop(nv, nc, nk, S1, S2, sp_spins, eigenvecs, kmap):  # calculate the bracket of two excitonic states with the spin operator
    bra = np.conj(eigenvecs[S1, :, :, :])  # k c v
    ket = eigenvecs[S2, :, :, :]  # k c v
    spin_val = 0.0
    for v in range(nv):
        for c in range(nc):
            for kbgw in range(nk):
                kqe = kmap[kbgw]
                t1 = bra[kbgw, c, v]
                for cp in range(nc):
                    t2 = ket[kbgw, cp, v]
                    t3 = sp_spins[kqe, nv + c, nv + cp]
                    mult = t1 * t2 * t3
                    spin_val += mult
                for vp in range(nv):
                    t2 = ket[kbgw, c, vp]
                    t3 = sp_spins[kqe, nv - v - 1, nv - vp - 1]
                    mult = t1 * t2 * t3
                    spin_val -= mult
    return spin_val


def main(path, spin_direction, nS):
    # read single particle spin pickle according to the chosen direction
    if spin_direction == 3:
        sp_spin_file_name = 'Sz'
        output_files_name = 'excitonic_Sz'
    if spin_direction == 1:
        sp_spin_file_name = 'Sx'
        output_files_name = 'excitonic_Sx'
    if spin_direction == 2:
        sp_spin_file_name = 'Sy'
        output_files_name = 'excitonic_Sy'

    spin_pickle = open(os.path.join(path, sp_spin_file_name), 'rb')
    sp_spins = pickle.load(spin_pickle)
    spin_pickle.close()

    # read eigenvectors.h5, according to the number of chosen excitonic states (first nS excitons)
    evecs_file_name = os.path.join(path, 'eigenvectors.h5')
    evecs = h5py.File(evecs_file_name, 'r')
    A_Skcv = evecs['exciton_data/eigenvectors'][0, :nS, :, :, :, 0, 0] + evecs['exciton_data/eigenvectors'][0, :nS, :, :, :, 0, 1] * 1j
    QEkpoints = evecs['mf_header/kpoints/rk'][()]
    BGWkpoints = evecs['exciton_header/kpoints/kpts'][()]
    evecs.close()
    nk = np.shape(A_Skcv)[1]
    nc = np.shape(A_Skcv)[2]
    nv = np.shape(A_Skcv)[3]
    assert(sp_spins.shape[1] == sp_spins.shape[2])
    assert(sp_spins.shape[1] == (nv + nc))
    assert(sp_spins.shape[0] == nk)

    kmap = np.array(map_grid2grid(BGWkpoints, QEkpoints))
    if np.allclose(kmap, range(nk)):
        print('k-grid in QE and BGW are identical')
    else:
        print('k-grid ordering in QE and BGW are different')


    output_mat = np.zeros([nS, nS], dtype=np.complex128)  # create empty array for calculated excitonic spin elements
    for s1 in range(nS):  # loop over the nS lowest-energy excitons
        for s2 in range(nS):  # loop over the nS lowest-energy excitons
            output_mat[s1, s2] = spin_loop(nv, nc, nk, s1, s2, sp_spins, A_Skcv, kmap)
    assert(np.allclose(output_mat, np.conj(output_mat).T))  # make sure that the result matrix is Hermitian


    pick_file = open(os.path.join(path, output_files_name), 'wb')  # open results pickle file
    pickle.dump(output_mat, pick_file)  # save the pickle
    pick_file.close()  # close the pickle file
    return


if __name__ == '__main__':
      import argparse
      parser = argparse.ArgumentParser()
      parser.add_argument('path', type=str)  # path to input and output folder
      parser.add_argument('spin_direction', type=int)  # spin direction you wish to calculate. x=1, y=2, z=3.
      parser.add_argument('nS', type=int)  # number of excitonic states you wish to calculate
      args = parser.parse_args()
      main(**vars(args))
