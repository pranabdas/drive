# BerkeleyGW HDF5 file format specification

Specification for all HDF5 files written by BerkeleyGW should be put here!

These files are processed by the `assemble_manual.py` script under the
`../user_manual/` older.  If you add any new input file here, they will
automatically be included in the user manual by the script
`assemble_manual.py`, and no further action is required by the user/developer.
