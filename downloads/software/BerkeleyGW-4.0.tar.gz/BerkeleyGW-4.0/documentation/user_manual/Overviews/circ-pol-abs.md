### Overview - Circularly Polarized Light Absorption
This patch facilitates the calculation of absorption for circularly polarized light in two-dimensional systems. The process involves two Python scripts: one to determine the linear combination of reciprocal lattice vectors that are perpendicular to each other (essential for non-orthogonal lattice vectors, as in transition metal dichalcogenides).

After identifying the vector coefficients yielding perpendicular directions, two absorption calculations are performed, focusing solely on the non-interacting electron-hole components, which are computationally relatively easy.

Subsequently, the second Python script computes the circularly polarized dipole matrix elements. Finally, the absorption calculation can be rerun using these dipole matrix elements.

Please follow the steps outlined in the notebook in the BSE/MagneticSpin directory. Note that the code is optimized for using the momentum operator in absorption, specifically tailored for 2D systems with the out-of-plane direction as the z-direction.
