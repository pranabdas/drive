# Environment Variable
  
Below a list of variables that can be exported on your environment to activate specific features
of BerkeleyGW.

- `export BGW_NUM_THREADS_SORT=4` <br/>
  Set the number of OpenMP threads to be used in the sorting algorithm. 
  
- `export BGW_HDF5_WRITE_REDIST=1` <br/> 
  In Full-Frequency calculations perform a data redistribution of the frequency epsilon over contiguous chunks of memory 
  to improve HDF5 I/O performance paying an extra communication cost. 
    - Activate using: `1`, `T`, `t`, `Y`, `y`
    - Deactivate using: `0`, `F`, `f`, `N`, `n`
    - Default: non active

- `export BGW_WFN_HDF5_INDEPENDENT=1` <br/>
  Use MPIO independent instead of collective, depending on the HDF5 implementation and architecture can improve performance. 
    - Activate using: `1`, `T`, `t`, `Y`, `y`
    - Deactivate using: `0`, `F`, `f`, `N`, `n`
    - Default: non active (`H5FD_MPIO_COLLECTIVE`)
    
- `export BGW_HDF5_BANDS_COMM_STYLE=1` <br/>
  Allows to change the communication style when reading in blocks of bands from `WFN` files.
    - `0` Native HDF5 all ranks read from file
    - `1` Using MPI collectives (BCast) (default)
    - `2` Using MPI point-to-point (Send/Recv) 
    
- `export BGW_SCALAPACK_MEM_RESCALE=0.5` <br/>
  Rescale the workspace memory in ScalaPACK diagonalization calls by the provided factor. 
  
- `export BGW_SCALAPACK_ALGO=1` <br/>
  Allows to select which diagonalization algorithm to use.
    - `-1` or `0` PDSYEVX
    - `1` PDSYEVR
    - `2` PZHEEVD
    
- `export BGW_ELPA_NO_GPU=1` <br/> 
  If ELPA is compiled with GPU support enable to switch to the CPU implementation. 
    - Activate using: `1`, `T`, `t`, `Y`, `y`
    - Deactivate using: `0`, `F`, `f`, `N`, `n`
    - Default: non active (GPU version)
