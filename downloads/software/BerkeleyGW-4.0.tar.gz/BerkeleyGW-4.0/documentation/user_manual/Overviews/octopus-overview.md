# Octopus

Octopus is a real-space DFT and TDDFT code available under the GPL from
<http://www.tddft.org/programs/octopus>. Support for BerkeleyGW output is
implemented in Octopus since version 4.1.0, and all required wrappers are
shipped within the Octopus code. For more information, see the BerkeleyGW
article in the Octopus wiki: <https://octopus-code.org/wiki/BerkeleyGW>.
