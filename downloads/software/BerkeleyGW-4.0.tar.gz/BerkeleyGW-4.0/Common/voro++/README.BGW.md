DISCLAIMER
==========

The ~BGW/Common/voro++ directory contains source code from voro++-0.4.6. The file LICENSE has
 the terms for distributing these files.

The following files are part of the BerkeleyGW package, and not voro++:
 - libtile_voro.cc
 - libtile_voro.h
 - test_voro.f90
 - README.BerkeleyGW

The following files were removed from the original voro++ distribution:
 - examples/*
 - html/*
 - man/*
 - scripts/*
 - src/README
 - src/Doxyfile
 - src/Makefile.dep

The following files were changed to better integrate with BerkeleyGW:
 - Makefile
 - Makefile.dep
 - src/Makefile
