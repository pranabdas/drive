#!/bin/bash -l

DIR=`dirname $0`
$DIR/asciify.py 2 $DIR/donkey.png $DIR/donkey.dat 72 4 7 12
