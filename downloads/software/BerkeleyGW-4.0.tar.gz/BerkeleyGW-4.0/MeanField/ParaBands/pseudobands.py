#!/usr/bin/env python

# Pseudobands
# Aaron R. Altman, Sudipta Kundu, Felipe H. da Jornada (2024)

# If using this script, please cite the work that made it possible:
# TODO: ADD CITATION

from __future__ import print_function
import h5py
import numpy as np
from scipy.optimize import minimize_scalar
import logging 
import time
import sys
import numbers

# so that logger doesn't try to truncate arrays
np.set_printoptions(threshold=sys.maxsize)

# set seed for testing on different machines
rng = np.random.default_rng(1282024) # today's date :) 

######################################################################
# Set of helper functions based on loss function and FEG
# See Supplemental Material of PRL for more details

C = 1 / (12 * np.pi**8) # atomic units
B = np.sqrt(2) / np.pi**2

def alpha(beta, E0, Emax, nspbps, nslice):
    dE = Emax - E0
    return (dE * (np.exp(beta)-1)) / (np.exp(beta) * (np.exp(nslice * beta) - 1))


def w(beta, j, E0, Emax, nspbps, nslice):
    return alpha(beta, E0, Emax, nspbps, nslice) * np.exp(j * beta)


def Ebar(beta, j, E0, Emax, nspbps, nslice):
    a = alpha(beta, E0, Emax, nspbps, nslice)
    width = w(beta, j, E0, Emax, nspbps, nslice)
    return E0 + a * np.exp(beta) * (np.exp(j * beta) - 1) / (np.exp(beta) - 1) - width / 2


def Loss(beta, E0=1, Emax=10, nspbps=1, nslice=10):
    out = 0
    for j in range(1, nslice+1):
        Ei = Ebar(beta, j, E0, Emax, nspbps, nslice)
        wi = w(beta, j, E0, Emax, nspbps, nslice)
        assert Ei > 0, Ei
        assert wi > 0, wi

        # FEG approximation to dimension of the subspace breaks down, let dim = 1 in this case
        if B * wi * np.sqrt(Ei) < 1:
            out += C * wi**2 / Ei**2
            continue

        l = C * wi**2 / Ei**2 + 1 / (Ei**2 * nspbps) * (1 - 1 / (B * wi * np.sqrt(Ei)))
        out += l
    return out


def optimize(E0=1, Emax=10, nspbps=1, nslice=10):
    tol=1e-9
    bnds = (tol, 1-tol)
    result = minimize_scalar(Loss, args=(E0, Emax, nspbps, nslice), bounds=bnds, method='bounded')
    # print(f'minimization results: \n{result}')
    # print(f'alpha: {alpha(result.x, E0, Emax, nspbps, nslice)}')
    return result

######################################################################
# Code for pseudobands 

def construct_blocks(el, n_copy, nslice, nspbps, uniform_width, max_freq):
    
    if uniform_width is None or uniform_width == 0.0:
        assert max_freq == 0.0
    
    # optimizing parameters
    if max_freq > 0:
        E0 = el[n_copy]
        slices = uniform_width*np.arange(max_freq//uniform_width -1) + E0
        start_exp = len(slices)
        
        E0new = slices[-1] + uniform_width
        Emax = el[-1]
        assert E0 > 0
        assert Emax > E0
        assert Emax > E0new
        assert E0new > E0

        res = optimize(E0new, Emax, nspbps, nslice)
        beta = res.x
        widths = np.insert(np.cumsum([w(beta, j, E0new, Emax, nspbps, nslice) 
                                      for j in range(1, nslice + 1)]), 0,0) + E0new
        slices = np.concatenate((slices, widths))
        
    else:
        E0 = el[n_copy]
        Emax = el[-1]
        assert E0 > 0
        assert Emax > E0, '''Largest protected band is degenerate with largest energy band. 
        This could be because you requested too many protected valence bands or pseudobands.'''

        res = optimize(E0, Emax, nspbps, nslice)
        beta = res.x
        slices = np.insert(np.cumsum([w(beta, j, E0, Emax, nspbps, nslice) 
                                      for j in range(1, nslice+1)]), 0,0) + E0
        start_exp = 0
    
    assert slices[0] == E0
    slices[-1] = Emax
    blocks = []
    nb_out = n_copy
    si = 0
    
    while si <= len(slices) - 2:
        if len(blocks) > 1:
            l = len(blocks)
            assert blocks[l-1][0] == blocks[l-2][1]+1
            
        first_en = slices[si]
        assert first_en > 0
        last_en = slices[si+1]
        assert last_en >= first_en
        si += 1
        
        first_idx = list(np.where(el >= first_en))
        last_idx = list(np.where(el <= last_en))
        
        # no bands in slice, mostly an issue for valence states (usually sparse)
        if first_idx[0][0] == last_idx[0][-1]: 
            blocks.append([first_idx[0][0], last_idx[0][-1]])
            continue
        elif first_idx[0][0] > last_idx[0][-1]: 
            continue
            
        blocks.append([first_idx[0][0], last_idx[0][-1]])
        nb_out += 1

    return np.asarray(blocks), start_exp


# fix signs/relative alignment
def fix_blocks(blocks, vc, ifmax, nb_orig):
    if vc == 'v':
        np.flip(blocks)
        blocks *= -1
        blocks += ifmax-1
        assert blocks[-1][-1] == 0
    
    elif vc == 'c':
        blocks += ifmax
        assert blocks[-1][-1] == nb_orig-1


# bunch of sanity checks, block construction for WFN and WFNq simultaneously 
def check_and_block(
    fname_in = None, fname_in_q = None, nv=-1, nc=100, nslice_v = 10, nslice_c
     = 100, uniform_width=None, max_freq=0., nspbps_v=2, nspbps_c=2, 
     verbosity=0, **kwargs):
    
    nv = int(nv)
    nc = int(nc)
    
    if uniform_width is None:
        assert max_freq == 0.
    else:
        assert uniform_width >= 0
    
    assert nv >= -1
    assert nc >= -1
    assert nslice_v > 0
    assert nslice_c > 0
    
    assert not (nv == -1 and nc == -1), \
        'Just copying input WFN file, no need to use this script for that.'
    
    if nv != -1: # not just copying
        assert nspbps_v >= 2, \
            'You must use at least 2 bands per slice to obtain meaningful results!'
    if nc != -1: # not just copying
        assert nspbps_c >= 2, \
            'You must use at least 2 bands per slice to obtain meaningful results!'
    
    f_in = h5py.File(fname_in, 'r')
    f_in_q = h5py.File(fname_in_q, 'r')

    flavor = f_in['mf_header/flavor'][()]
    flavor_q = f_in_q['mf_header/flavor'][()]
    assert flavor == flavor_q, 'Flavors of WFN and WFNq dont match!'
    if flavor not in [1,2]:
        raise ValueError('Invalid flavor')

    en_orig = f_in['mf_header/kpoints/el'][()]
    nb_orig = f_in['mf_header/kpoints/mnband'][()]
    nspinor = f_in['mf_header/kpoints/nspinor'][()]
    ifmax = f_in['mf_header/kpoints/ifmax'][()]
    
    en_orig_q = f_in_q['mf_header/kpoints/el'][()]
    nb_orig_q = f_in_q['mf_header/kpoints/mnband'][()]
    nspinor_q = f_in['mf_header/kpoints/nspinor'][()]
    ifmax_q = f_in_q['mf_header/kpoints/ifmax'][()]
    
    assert nspinor == nspinor_q, 'WFN and WFNq have different numbers of spinors.'

    ns, nk = ifmax.shape
    ns_q, nk_q = ifmax_q.shape
    assert ns == ns_q, 'WFN and WFNq have different numbers of spins.'

    # compute fermi, taking into account all kpts from WFN & WFNq
    is_idx, ik_idx = np.ogrid[:ns, :nk]
    is_idx_q, ik_idx_q = np.ogrid[:ns_q, :nk_q]
    VBM = np.concatenate((en_orig[is_idx, ik_idx, ifmax-1], 
                          en_orig_q[is_idx_q, ik_idx_q, ifmax_q-1]), axis=1)
    CBM = np.concatenate((en_orig[is_idx, ik_idx, ifmax], 
                          en_orig_q[is_idx_q, ik_idx_q, ifmax_q]), axis=1)
    fermi = (np.max(VBM) + np.min(CBM)) / 2.0 
    logger.info(f'E_Fermi = {fermi} Ry')

    # increase nv by this value to avoid partially-occupied bands
    shift_nv = max(np.amax(ifmax), np.amax(ifmax_q)) \
                - min(np.amin(ifmax), np.amin(ifmax_q))
    shift_nv = int(shift_nv)
    if nv != -1:
        nv += shift_nv

    # ifmax needs to be referenced to its max for the same reason
    ifmax = int(max(np.amax(ifmax), np.amax(ifmax_q)))
    logger.info(f'max(ifmax) = {ifmax}')
    logger.info(f'max(ifmax) - min(ifmax) = {shift_nv}')    
    
    assert nv <= ifmax
    assert nc <= nb_orig - ifmax
    
    en_orig -= fermi
    en_orig_q -= fermi
   
    # average over kpoints
    el_all_v = -np.flip(np.mean(np.concatenate((en_orig[...,:ifmax], 
                                    en_orig_q[...,:ifmax]), axis=1)[0], axis=0))

    el_c = np.mean(en_orig[0,:,ifmax:None], axis=0)    
    # hopefully there are no states at 0 energy... TODO: add assert statement

    if nv != -1:
        blocks_v, start_exp_v = construct_blocks(el_all_v, nv, nslice_v, 
                                                 nspbps_v, uniform_width, max_freq)
        fix_blocks(blocks_v, 'v', ifmax, nb_orig)
        blocks_en_v = [[np.mean(en_orig[...,b[0]]), np.mean(en_orig[...,b[1]])] for b in blocks_v]
        
        if verbosity > 0:
            logger.info(f'index of first exponential valence slice: {start_exp_v}')
            logger.info(f'valence slices: {blocks_v}')
            logger.info(f'valence slice energies (Ry) (relative to E_Fermi): {blocks_en_v}')
            
        nslices_v = len(blocks_v)
        nspb_v = nslices_v * nspbps_v
        nb_out_v = nv + nspb_v
        
        if nb_out_v > ifmax:
            logger.error('More total valence states (copied + SPBs) than original'
                         'valence bands ==> no computational savings in GW steps.'
                         'Choose smaller nv, nspbps_v, or larger efrac_v')
            raise ValueError('More total valence states (copied + SPBs) than original'
                         'valence bands ==> no computational savings in GW steps.'
                         'Choose smaller nv, nspbps_v, or larger efrac_v')
            
        assert len(blocks_v) == nslices_v
        
    else:
        logger.info('No valence pseudobands')
            
    if nc != -1:
        blocks_c, start_exp_c = construct_blocks(el_c, nc, nslice_c, nspbps_c,
                                                  uniform_width, max_freq)
        fix_blocks(blocks_c, 'c', ifmax, nb_orig)
        blocks_en_c = [[np.mean(en_orig[...,b[0]]), np.mean(en_orig[...,b[1]])] for b in blocks_c]

        if verbosity > 0:
            logger.info(f'index of first exponential conduction slice: {start_exp_c}')
            logger.info(f'conduction slices: {blocks_c}')
            logger.info(f'conduction slice energies (Ry) (relative to E_Fermi): {blocks_en_c}')
        
        nslices_c = len(blocks_c)
        nspb_c = nslices_c * nspbps_c
        nb_out_c = nc + nspb_c
        
        assert len(blocks_c) == nslices_c
    
    else: 
        logger.info('No conduction pseudobands')

    # get SPB params, then close files
    params_from_parabands = {}
    if 'parabands/pseudobands/nc' in f_in:
        params = f_in['parabands/pseudobands']
        params_from_parabands['nc']= params['nc'][()]
        params_from_parabands['n_subspaces'] = params['n_subspaces'][()]
        params_from_parabands['num_per_subspace'] = params['num_per_subspace'][()]
        
    f_in.close()
    f_in_q.close()
   
    if nv != -1 and nc != -1:
        logger.info(f'''
        nslices_c = {nslices_c}
        nslices_v = {nslices_v}
        nspb_c_total = {nspb_c}
        nspb_v_total = {nspb_v}
        nb_out_c_total = {nb_out_c}
        b_out_v_total = {nb_out_v}
        ''') 
        return nv, nc, blocks_v, blocks_c, ifmax, params_from_parabands
    elif nv == -1 and nc != -1:
        logger.info(f'''
        nslices_c = {nslices_c}
        nspb_c_total = {nspb_c}
        nb_out_c_total = {nb_out_c}
        ''') 
        return nv, nc, None, blocks_c, ifmax, params_from_parabands
    elif nv != -1 and nc == -1:
        logger.info(f'''
        nslices_v = {nslices_v}
        nspb_v_total = {nspb_v}
        nb_out_v_total = {nb_out_v}
        ''') 
        return nv, nc, blocks_v, None, ifmax, params_from_parabands


def fill_pseudoband_params(fout, vc, nprot, nslice, nspbps, max_freq, uniform_width):
    group = 'pseudobands/' + vc
    fout[group].create_dataset('nprot', (), data=nprot)
    fout[group].create_dataset('nslice', (), data=nslice)
    fout[group].create_dataset('nspbps', (), data=nspbps)
    if (isinstance(max_freq, numbers.Number) and isinstance(uniform_width, numbers.Number)): 
        fout[group].create_dataset('max_freq', (), data=max_freq)
        fout[group].create_dataset('uniform_width', (), data=uniform_width)   
    

# nv and nc bands are copied. SPBS are constructed outside this range
# nv and nc are passed from check_and_block to vars nv_prot, nc_prot
def pseudoband(
    qshift, nv_prot, nc_prot, blocks_v, blocks_c, ifmax, params_from_parabands, 
    fname_in = None, fname_out = None, fname_in_q = None, fname_out_q 
    = None, fname_in_NNS = None, fname_out_NNS = None, nspbps_v=2,
     nspbps_c=2, max_freq=0.0, uniform_width=None, single_band=False,
     copydirectly=True, verbosity=0, **kwargs
     ):
    
    # to avoid conflict with variable names
    nv, nc = nv_prot, nc_prot

    start = time.time()
        
    if qshift == 0:
        f_in = h5py.File(fname_in, 'r')
        f_out = h5py.File(fname_out, 'w')
        logger.info(f'fname_in = {fname_in}\n fname_out = {fname_out}\n ')
    elif qshift == 1:
        nc = -1
        f_in = h5py.File(fname_in_q, 'r')
        f_out = h5py.File(fname_out_q, 'w')
        logger.info(f'fname_in = {fname_in_q}\n fname_out = {fname_out_q}\n ')
    elif qshift == 2:
        nc = -1
        f_in = h5py.File(fname_in_NNS, 'r')
        f_out = h5py.File(fname_out_NNS, 'w')
        logger.info(f'fname_in = {fname_in_NNS}\n fname_out = {fname_out_NNS}\n ')
        
    nv = int(nv)
    nc = int(nc)
    mnband = f_in['mf_header/kpoints/mnband'][()]
    
    assert nv >= -1
    assert nc >= -1
    if nc > mnband - ifmax:
        nc = -1
        logger.warning('nc > mnband - ifmax, the original number of conduction states. Setting nc = -1')
    if nv > ifmax:
        nv = -1
        logger.warning('nv > ifmax, the original number of valence states. Setting nv = -1')
    
    if nv != -1:
        nslices_v = len(blocks_v)
        nspb_v = nslices_v * nspbps_v
        nb_out_v = nv + nspb_v
    else:
        nslices_v = 0
        nb_out_v = ifmax
     
    if nc != -1:
        nslices_c = len(blocks_c)
        nspb_c = nslices_c * nspbps_c
        nb_out_c = nc + nspb_c
    else:
        nslices_c = 0
        nb_out_c = mnband - ifmax
    
    if single_band:
        nspbps_v = 1
        nspbps_c = 1
        
    flavor = f_in['mf_header/flavor'][()]
    if flavor == 1:
        viewtype = np.float64
    elif flavor == 2:
        viewtype = np.complex128

    nk = f_in['mf_header/kpoints/nrk'][()]
    nspin = f_in['mf_header/kpoints/nspin'][()]
    nspinor = f_in['mf_header/kpoints/nspinor'][()]
    ngk = f_in['mf_header/kpoints/ngk'][()]
    cum_ngk = np.insert(np.cumsum(ngk), 0, 0)
    
    # Cannot read from this file if it exists due to different numbers of k-points in WFN and WFNq
    # Writing just for logging purposes
    if qshift == 0:
        phases_file = h5py.File('phases'+fname_out[0:-3]+'.h5', 'w')
    elif qshift == 1:
        phases_file = h5py.File('phases'+fname_out_q[0:-3]+'.h5', 'w')
    elif qshift == 2: 
        phases_file = h5py.File('phases'+fname_out_NNS[0:-3]+'.h5', 'w')
    else:
        raise ValueError('bad value for qshift')
    
    f_out.copy(f_in['mf_header'], 'mf_header')
    f_out.create_group('wfns')
    f_out.copy(f_in['wfns/gvecs'], 'wfns/gvecs')
    f_out['mf_header/kpoints/mnband'][()] = nb_out_v + nb_out_c
    f_out['mf_header/kpoints/ifmax'][()] = nb_out_v
    
    f_out.create_group('pseudobands')
    f_out.create_group('pseudobands/conduction')
    f_out.create_group('pseudobands/valence')
    
    # fill in pseudobands params into these groups
    if nc == -1:
        try:
            nprot = params_from_parabands['nc'][()]
            nslice = params_from_parabands['n_subspaces'][()]
            nspbps = params_from_parabands['num_per_subspace'][()]
            fill_pseudoband_params(f_out, 'conduction', nprot, nslice, nspbps, max_freq, uniform_width)
        except:
            fill_pseudoband_params(f_out, 'conduction', nc, len(blocks_c), nspbps_c, max_freq, uniform_width)
    else:
        fill_pseudoband_params(f_out, 'conduction', nc, len(blocks_c), nspbps_c, max_freq, uniform_width)
        
    if nv != -1:
        fill_pseudoband_params(f_out, 'valence', nv, len(blocks_v), nspbps_v, max_freq, uniform_width)
    
    phases_file.copy(f_in['mf_header'], 'mf_header')
    phases_file.create_group('phases')

    def resize(file, name):
        file.move(name, name + '_orig_pb')
        shape = list(file[name + '_orig_pb'].shape)
        shape_orig = shape
        shape[-1] = nb_out_v + nb_out_c
        file.create_dataset(name, shape, dtype='d')
        # file[name][:, :, :min(shape_orig[-1], nb_out_v+nb_out_c)] = file[name + '_orig_pb'][:, :, :min(shape_orig[-1], nb_out_v+nb_out_c)]
        del file[name + '_orig_pb']
           
    resize(f_out, 'mf_header/kpoints/occ')
    resize(f_out, 'mf_header/kpoints/el')
    
    if nv != -1 and nc != -1:
        logger.info(f'Copying {nv=} + {nc=} = {nv+nc} protected bands')
    elif nv == -1 and nc != -1:
        logger.info(f'Copying {ifmax=} + {nc=} = {ifmax+nc} protected bands')
    elif nv != -1 and nc == -1:
        logger.info(f'Copying {mnband-ifmax=} + {nv=} = {mnband-ifmax + nv} protected bands')
        
    shape = list(f_in['wfns/coeffs'].shape)
    shape[0] = nb_out_v + nb_out_c
    f_out.create_dataset('wfns/coeffs', shape, 'd')
    
    shape_phases = (ifmax-nv, nk, nspbps_v, 2,)
    phases_file.create_dataset('phases/coeffs', shape_phases, 'd')
   
    if copydirectly:
        # FHJ: this can take quite a while for some systems..
        logger.warning('copydirectly=True. Copying all protected bands at once, can be slow if copying >1000 bands')
        # logger.info(f'nb_out_v-nv:nb_out_v+nc: {(nb_out_v-nv, nb_out_v+nc)} \n ifmax-nv:ifmax+nc: {(ifmax-nv, ifmax+nc)}')
        if nv != -1 and nc != -1:
            f_out['wfns/coeffs'][nb_out_v-nv:nb_out_v+nc, :, :] = f_in['wfns/coeffs'][ifmax-nv:ifmax+nc, :, :]
            f_out['mf_header/kpoints/el'][:,:,nb_out_v-nv:nb_out_v+nc] = f_in['mf_header/kpoints/el'][:,:,ifmax-nv:ifmax+nc]
        elif nv == -1 and nc != -1:
            f_out['wfns/coeffs'][0:nb_out_v+nc, :, :] = f_in['wfns/coeffs'][0:ifmax+nc, :, :]
            f_out['mf_header/kpoints/el'][:,:,0:nb_out_v+nc] = f_in['mf_header/kpoints/el'][:,:,0:ifmax+nc]
        elif nv != -1 and nc == -1:
            f_out['wfns/coeffs'][nb_out_v-nv:None, :, :] = f_in['wfns/coeffs'][ifmax-nv:None, :, :]
            f_out['mf_header/kpoints/el'][:,:,nb_out_v-nv:None] = f_in['mf_header/kpoints/el'][:,:,ifmax-nv:None]  
        
    else: ### FIXME: indices not correct (if copydirectly indices are correct though); phases_file not included yet
        raise NotImplementedError
        nbs_block = 1000
        ibs_start = range(ifmax-nv, ifmax + nc -1, nbs_block)
        if Bar is not None:
            bar = Bar('Copying protected bands', max=len(ibs_start), bar_prefix=' [', bar_suffix='] ',
                      fill='#', suffix='%(percent)d%% - Remaining: %(eta_td)s')
        for ib in ibs_start:
            if Bar is not None:
                bar.next()
            ib1, ib2 = ib, min(ib + nbs_block, ifmax+nv+nc-1)
            tmp = f_in['wfns/coeffs'][ib1:ib2, :, :, :]
            try:
                f_out['wfns/coeffs'][ib1:ib2, :, :] = tmp
            except Exception as err:
                frameinfo = getframeinfo(currentframe())
                logger.error(frameinfo.lineno)
                logger.error(err)
        if Bar is not None:
            bar.finish()
    
    if nv != -1: 
        logger.info('Creating {} valence pseudobands'.format(nspb_v))
        ib = nb_out_v-nv-1

        for b in blocks_v:
            num_bands_in = b[0] - b[1] + 1
            
            if verbosity > 1:
                logger.info(f'slice_index, slice: {ib - (nb_out_v-nv-1), b}')

            if single_band:
                band_avg = b[0] + (b[1] - b[0]) // 2
                f_out['wfns/coeffs'][ib, :, :] = (f_in['wfns/coeffs'][band_avg, :, :]
                                                  * np.sqrt(float(b[1] - b[0] + 1)))
                f_out['mf_header/kpoints/el'][:, :, ib] = f_in['mf_header/kpoints/el'][:, :, band_avg].mean(axis=-1)
                ib -= 1

            elif nspbps_v == 1:
                if b[0] == 1:
                    f_out['wfns/coeffs'][ib, :, :] = f_in['wfns/coeffs'][0, :, :].sum(axis=0)
                    f_out['mf_header/kpoints/el'][:, :, ib] = f_in['mf_header/kpoints/el'][:, :, 0].mean(axis=-1)
                elif b[0] == 0:
                    continue
                else:
                    f_out['wfns/coeffs'][ib, :, :] = f_in['wfns/coeffs'][b[1]:b[0]+1, :, :].sum(axis=0)
                    f_out['mf_header/kpoints/el'][:, :, ib] = f_in['mf_header/kpoints/el'][:, :, b[1]:b[0]+1].mean(axis=-1)
                
                # sum rule: <SPB|SPB> = num_band_in * nk
                logger.info(f'num_bands_in * nk, norm(SPB)**2: '
                +f"{num_bands_in * nk}, {np.linalg.norm(f_out['wfns/coeffs'][ib, :, :].view(viewtype))**2}")
                assert abs(np.linalg.norm(f_out['wfns/coeffs'][ib, :, :].view(viewtype))**2 - num_bands_in * nk) <= 1e-9
                                 
                ib -= 1
                
            else: # nspbps > 1
                if b[0] == 0:
                    continue
                else:
                    coeffs = f_in['wfns/coeffs'][b[1]:b[0]+1, :, :, :].view(viewtype)
                    el = f_in['mf_header/kpoints/el'][:, :, b[1]:b[0]+1].mean(axis=-1)

                    for ispb in range(nspbps_v):
                        # Phases are normalized to the DOS / sqrt(number_pseudobands)
                        # We use different phases for different kpts, which is fine
                        # but not necessary since pseudobands only care about the 
                        # band index. Note that we dont bother using different phases
                        # for the spin/spinor index, because I was too lazy to 
                        # implement it, and again, it's not required.
                        # The sum rule must account for spins/spinors though.
                        phases = rng.random((num_bands_in, nk,))
                        if flavor == 1:
                            phases = np.sign(phases - 0.5)
                            phases[phases == 0.0] = 1.0 # we need to conserve the norm
                            phases /= np.sqrt(float(nspbps_v))
                        elif flavor == 2:
                            phases = np.exp(2 * np.pi * 1.0j * phases) / np.sqrt(float(nspbps_v))

                        phases_file['phases/coeffs'][b[1]:b[0]+1, :, ispb, :] =\
                              phases.view(np.float64).reshape((phases.shape + (flavor,)))
                        # nk in WFN and WFNq are often different, cannot reuse phases from file

                        if verbosity > 1:
                            logger.info(f'phases.shape for SPB {ib}: {phases.shape}')
                            logger.info(f'coeffs.shape for SPB {ib}: {coeffs.shape}')

                        # Make sure we do a complex mult., and then view result as float
                        spb = [np.tensordot(coeffs[:,:,cum_ngk[k]:cum_ngk[k+1]], 
                                            phases[:,k], axes=(0, 0)) for k in range(nk)]
                        spb = np.concatenate(spb, axis=-2)

                        f_out['wfns/coeffs'][ib, :, :] = spb.view(np.float64)
                        f_out['mf_header/kpoints/el'][:, :, ib] = el
                        
                        # sum rule: <SPB|SPB> = num_band_in * nk * nspin / num_per_slice
                        # note: nspinor is implicitly included in num_band_in
                        logger.info(f'num_bands_in*nk*ns*nspinor/nspbps_v, norm(SPB)**2: '
                        +f'{num_bands_in/float(nspbps_v) * nk * nspin}, {np.linalg.norm(spb)**2}')
                        assert abs(np.linalg.norm(spb)**2 - num_bands_in * nk * nspin / float(nspbps_v)) <= 1e-9

                        ib -= 1
                    
    if qshift >= 1:
        f_out.close()
        phases_file.close()
        f_in.close()
        end = time.time()
        logger.info(f'Done! Time taken: {round(end-start,2)} sec\n\n\n')
        return
        
    if nc != -1:
        logger.info('Creating {} conduction pseudobands'.format(nspb_c))
        ib = nb_out_v + nc 

        for b in blocks_c:
            
            num_bands_in = b[1] - b[0] + 1
            
            if verbosity > 1:
                logger.info(f'slice_index, slice: {ib-(nb_out_v + nc), b}')

            if single_band:
                band_avg = b[0] + (b[1] - b[0]) // 2
                f_out['wfns/coeffs'][ib, :, :] = (f_in['wfns/coeffs'][band_avg, :, :]
                                                  * np.sqrt(float(b[1] - b[0] + 1)))
                f_out['mf_header/kpoints/el'][:, :, ib] = f_in['mf_header/kpoints/el'][:, :, band_avg].mean(axis=-1)
                ib += 1
            elif nspbps_c == 1:
                f_out['wfns/coeffs'][ib, :, :] = f_in['wfns/coeffs'][b[0]:b[1] + 1, :, :].sum(axis=0)
                f_out['mf_header/kpoints/el'][:, :, ib] = f_in['mf_header/kpoints/el'][:, :, b[0]:b[1] + 1].mean(axis=-1)
                if verbosity > 1:
                    avgen = f_in['mf_header/kpoints/el'][:, :, b[0]:b[1] + 1].mean(axis=-1)
                    logger.info(f'energy of slice {b}: {avgen}')
                    
                # sum rule: <SPB|SPB> = num_band_in * nk
                logger.info(f'num_bands_in, norm(SPB)**2: {num_bands_in * nk}, '
                +f"{np.linalg.norm(f_out['wfns/coeffs'][ib, :, :].view(viewtype))**2}")
                assert abs(np.linalg.norm(f_out['wfns/coeffs'][ib, :, :].view(viewtype))**2 - num_bands_in * nk) <= 1e-9
                
                ib += 1

            else:
                coeffs = f_in['wfns/coeffs'][b[0]:b[1] + 1, :, :, :].view(viewtype)
                el = f_in['mf_header/kpoints/el'][:, :, b[0]:b[1] + 1].mean(axis=-1)
                num_bands_in = b[1] - b[0] + 1
                for ispb in range(nspbps_c):
                    # no phases file for conduction states
                    # Phases are normalized to the DOS / sqrt(number_pseudobands)
                    phases = rng.random((num_bands_in, nk,))
                    if flavor == 1:
                        phases = np.sign(phases - 0.5)
                        phases[phases == 0.0] = 1.0 # we need to conserve the norm
                        phases /= np.sqrt(float(nspbps_c))
                    elif flavor == 2:
                        phases = np.exp(2 * np.pi * 1.0j * phases) / np.sqrt(float(nspbps_c))

                    if verbosity > 1:
                            logger.info(f'phases.shape for SPB {ib}: {phases.shape}')
                            logger.info(f'coeffs.shape for SPB {ib}: {coeffs.shape}')

                    # Make sure we do a complex mult., and then view result as float
                    spb = np.concatenate([np.tensordot(coeffs[:,:,cum_ngk[k]:cum_ngk[k+1]],
                                             phases[:,k], axes=(0, 0)) for k in range(nk)], axis=-2)

                    f_out['wfns/coeffs'][ib, :, :] = spb.view(np.float64)
                    f_out['mf_header/kpoints/el'][:, :, ib] = el
                    
                    # sum rule: <SPB|SPB> = num_band_in / num_per_slice * nk * nspin
                    # note: nspinor is implicitly included in num_band_in
                    logger.info(f'num_bands_in*nk*ns*nspinor/nspbps_c, norm(SPB)**2: ' 
                    +f'{num_bands_in/float(nspbps_c) * nk * nspin}, {np.linalg.norm(spb)**2}')
                    assert abs(np.linalg.norm(spb)**2 - num_bands_in * nk * nspin / float(nspbps_c)) <= 1e-9

                    ib += 1
    
    f_out.close()
    phases_file.close()
    f_in.close()
    end = time.time()
    logger.info(f'Done! Time taken: {round(end-start,2)} sec\n\n\n')


if __name__ == "__main__":
    import argparse
    
    desc = '''Constructs stochastic pseudobands given an input WFN. Protected 
    bands are copied without modification, and states higher in energy are 
    aggregated into subspaces and represented with pseudobands, each one spanning 
    the energy range [En, En * E_frac], where En is the energy of the first 
    state in the subspace relative to E_Fermi, and E_frac is a constant determined 
    by the number of slices.'''
    parser = argparse.ArgumentParser(description=desc)
    parser.add_argument('--fname_in', help='Input WFN.h5, in HDF5 format', required=True)
    parser.add_argument('--fname_in_q', help='Input WFNq.h5, in HDF5 format', required=True)
    parser.add_argument('--fname_in_NNS', help='Input WFNq_NNS.h5, in HDF5 format')
    parser.add_argument('--fname_out', help='Output WFN.h5 with pseudobands, in HDF5 format', required=True)
    parser.add_argument('--fname_out_q', help='Output WFNq.h5 with pseudobands, in HDF5 format', required=True)
    parser.add_argument('--fname_out_NNS', help='Output WFNq_NNS.h5 with pseudobands, in HDF5 format')
    parser.add_argument('--NNS', default=0, help='Using separate NNS WFNq?')
    parser.add_argument('--nv', '--N_P_val', type=int, default=-1,
                        help='Number of protected valence bands counting from VBM.')
    parser.add_argument('--nc', '--N_P_cond', type=int, default=100,
                        help='Number of protected conduction bands counting from CBM.')
    parser.add_argument('--nslice_v', '--N_S_val', type=int, default=10,
                        help='Number of subspaces spanning the total energy range of the valence bands.')
    parser.add_argument('--uniform_width', type=float, default=None,
                        help=('Constant width accumulation window (Ry) for slices with |energy - E_F| <= max_freq.'))
    parser.add_argument('--nslice_c', '--N_S_cond', type=int, default=100,
                        help='Number of subspaces spanning the total energy range of the conduction bands.')
    parser.add_argument('--max_freq', type=float, default=0.0,
                        help=('''Maximum energy (Ry) before standard slicing kicks in. 
                            This should be at least the maximum frequency for which you plan to evaluate epsilon.'''))
    parser.add_argument('--nspbps_v', '--N_xi_val', type=int, default=2,
                        help='Number of stochastic pseudobands per valence slice. Must be at least 2.')
    parser.add_argument('--nspbps_c', '--N_xi_cond', type=int, default=2,
                        help='Number of stochastic pseudobands per conduction slice. Must be at least 2.')
    parser.add_argument('--copydirectly', default=True,
                        help=('Direct copying for protected bands. If False, then copying is done in chunks to limit memory usage. Set to False is you have a large number of protected bands.'))
    parser.add_argument('--verbosity', type=int, default=2,
                        help='Set verbosity level')
    parser.add_argument('--single_band', default=False, action='store_true',
                        help='Use a single band instead of a stochastic combination')
    
    args = parser.parse_args()
    
    logging.basicConfig(filename=vars(args)['fname_out'][0:-3]+'.log', level=logging.DEBUG, 
                    format='%(asctime)s %(levelname)s %(name)s %(message)s')
    logger=logging.getLogger(__name__)
    
    printinfo = '\n'
    printinfo += ('-'*100 + '\n')*3 + '\n'
    printinfo += ' '*39 + '\033[1m' + 'STOCHASTIC PSEUDOBANDS' + '\033[0m' + '\n\n\n'
    printinfo += ' '*10 + 'This calculation is based on the algorithm developed in the following reference.\n'
    printinfo += ' '*24 + 'Please cite it to give proper credit to the authors:\n\n'
    printinfo += ' '*9 + 'A. R. Altman, S. Kundu, F. H. da Jornada, Mixed Stochastic-Deterministic Approach\n'
    printinfo += ' '*8 + 'for Many-Body Perturbation Theory Calculations, Phys. Rev. Lett. 132, 086401 (2024).\n'
    printinfo += ('-'*100 + '\n')*3

    logger.info(printinfo)

    logger.info(vars(args))
    
    out = check_and_block(**vars(args))
    
    pseudoband(0, *out, **vars(args))
    
    pseudoband(1, *out, **vars(args))
    
    if int(vars(args)['NNS']) == 1:
        pseudoband(2, *out, **vars(args))
