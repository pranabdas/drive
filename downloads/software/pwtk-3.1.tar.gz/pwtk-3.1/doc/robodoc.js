/****h* ROBODoc/ROBODoc Javascript support
 * FUNCTION
 *   This is the default Javascript library for documentation
 *   generated with ROBODoc.
 *   You can edit this file to your own liking and then use
 *   it with the option
 *      --js <filename>
 ******
 * $Id: html_generator.c,v 1.95 2019/01/04 23:58:00 cashy Exp $
 */
