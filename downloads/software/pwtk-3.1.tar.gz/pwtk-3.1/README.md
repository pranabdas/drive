![PWTK](web-page/images/pwtk-title.png)

[PWTK](http://pwtk.ijs.si/) stands for PWscf ToolKit. It is a Tcl scripting interface for
[Quantum ESPRESSO](https://www.quantum-espresso.org/).

*PWTK got its name because, initially, it only supported the PWscf
subset of QE programs, and the name "Quantum ESPRESSO" did not yet
exist when the PWTK project was initiated.*

[![License: GPL v2](https://img.shields.io/badge/License-GPL%20v2-blue.svg)](https://www.gnu.org/licenses/old-licenses/gpl-2.0.en.html)


## Getting started

* Tcl is required to run PWTK (see the INSTALL file)

* the name of the PWTK's executable is **pwtk**, and the usage is:
  
        pwtk script.pwtk
           (this executes the script "script.pwtk")
      
        pwtk
           (this way, PWTK enters the interactive mode)
  
  For further info, see:
  
        pwtk -h
           (this prints help, i.e., info about various options)
     
* to start learing PWTK, see http://pwtk.ijs.si/documentation.html

* if the Quantum ESPRESSO binaries are not on `PATH`, one should
  configure PWTK to specify where the PWTK binaries are located (see
  the [Installation and Configuration Tutorial](http://pwtk.ijs.si/install-tutorial.html) 
  for how to do it)

* there are several documented examples in the [examples/](examples/) directory to start with
